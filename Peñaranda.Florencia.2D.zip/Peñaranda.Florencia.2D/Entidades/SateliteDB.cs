﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Entidades
{
    class SateliteDB : IAstro<Satelite>
    {
        public bool Guardar("BASE DE DATOS", Satelite datos)
        {
            bool retorno = false;
            try
            {
                Satelite sat = new Satelite();
                sat =  (Satelite)datos;
                SqlConnection conexion = new SqlConnection("BASE DE DATOS");
                conexion.Open();
                StringBuilder cadena = new StringBuilder();
                cadena.AppendFormat("INSERT INTO Satelites(duraOrbita, duraRotacion, nombre) VALUES({0},{1},'{2}')", datos.DuraOrbita, datos.DuraRotacion, datos.Nombre);
 
                SqlCommand comando = new SqlCommand(cadena.ToString(), conexion);
                if (comando.ExecuteNonQuery() == 1)
                {
                    retorno = true;
                }
                conexion.Close();

            }
            catch (Exception e)
            {
                throw new SateliteException(e);
            }

            return retorno;
        }

    }
}
